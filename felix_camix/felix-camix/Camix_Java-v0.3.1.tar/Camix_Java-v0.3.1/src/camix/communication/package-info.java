/**
 * Package camix.communication du programme Camix.
 * 
 * <p>Ce package fournit les classes de communication de Camix 
 * ainsi que la suite de tests associée.</p>
 * 
 * @version 0.3.1
 * @author Matthias Brun
 */
package camix.communication;

