/**
 * Package felix.communication du programme Felix.
 * 
 * <p>Ce package fournit la communication entre Felix et Camix 
 * ainsi que la suite de tests associée.</p>
 * 
 * @version 0.4.1
 * @author Matthias Brun
 */
package felix.communication;
