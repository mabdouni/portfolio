/**
 * Package felix.controleur du programme Felix.
 * 
 * <p>Ce package fournit le contrôleur du programme Felix 
 * ainsi que la suite de tests associée.</p>
 * 
 * @version 0.4.1
 * @author Matthias Brun
 */
package felix.controleur;
