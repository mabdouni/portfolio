/**
 * Package monix.vue du programme Felix.
 * 
 * <p>Ce package fournit les vues du programme Felix
 * ainsi que la suite de tests associée.</p>
 * 
 * @version 0.3.1
 * @author Matthias Brun
 */
package felix.vue;
